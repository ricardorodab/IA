José Ricardo Rodríguez Abreu
309216139
Práctica no. 7
