José Ricardo Rodríguez Abreu
309216139
Práctica No. 8
Clase principal: aGeneticos.java

Si lo ejecuta sin parámetros: "java aGeneticos" el tablero será de 8 y la muestra de 50.
Puede cambiar los valores del tablero y la muestra llamando al programa:
"java aGeneticos <Tamaño del tablero> <Tamaño de la muestra>"
