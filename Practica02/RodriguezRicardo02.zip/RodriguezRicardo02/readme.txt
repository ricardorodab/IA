José Ricardo Rodríguez Abreu
309216139
Practica 02

Antes de hacer las simetrías el programa sólo hacía dos niveles rápido ya que al llegar al cuarto se quedaba haciendo las cuentas y el algoritmo para sacar a los hijos de cada jugada.

Después de la simetría evitabamos casos en los que de uno podríamos llegar a otro.
