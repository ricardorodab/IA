José Ricardo Rodríguez Abreu
309216139
Práctica No. 1
Anexo captura de pantallas de evoluciones.
